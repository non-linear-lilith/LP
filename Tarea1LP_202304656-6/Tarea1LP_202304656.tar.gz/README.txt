Katherine Huidobro P200
202304656-6 

Instrucciones:
- Instalar python 3
- insertar el archivo 
- usar el comando "python3 tarea.py" para interpretar el codigo de "tarea.py" usando python3
